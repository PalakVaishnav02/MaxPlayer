var $ = jQuery;
$(document).ready(function () {
    // Your array data
    var youtube = [
        {
            "id": "SWRbd9Ls_kM" 
        },
        {
            "id": "WxIcVwFshEU"
        },
        {
            "id": "m5TIzBGyctY"
        },
        {
            "id": "L7c4wS7T_T8"
        },
        {
            "id": "Dp3K5LVTMNQ"
        },
        {
            "id": "Mlk888FiI8A"
        },
        {
            "id": "o623TB-mY6A"
        },
        {
            "id": "Q13CishCKXY"
        },
        {
            "id": "2DXY9cR7vN4"
        },
        {
            "id": "3DDkacecdrU"
        },
        {
            "id": "rOZaxdPYP7U"
        },
        {
            "id": "2nd4KHj6Wgk"
        }

    ];
    var id;
    youtube.forEach(myFunction);
    youtube.forEach(myfun);
    function myFunction(value, key) {
        id = value.id;
        console.log(id);
        var div = '<div class="col-lg-4 youtube_class">'+
           
            '<div id=i_' + id + ' class="youtube_items">' +
            '</div>' +
           
            '</div>';
        $("#youtube_video").append(div);
    }

    function myfun(value, key) {
        id = value.id;
        console.log(id);
        $("#i_" + id).append($("<iframe/> ", {
            src: "https://youtube.com/embed/" + id + "?autoplay=1",
            frameborder: 0,
            width: "100%",
            height: 300
        }));
    }
    
 
});